<?php

    include 'conexion_be.php';

    $nombre_completo = $_POST['nombre_completo'];
    $correo = $_POST['correo'];
    $contrasena = $_POST['contrasena'];

    //encripatamiento de contraseña
    //$contrasena = hash('sha512',$contrasena);


    $query = "INSERT INTO usuarios(nombre_completo, correo, contrasena) 
    VALUES('$nombre_completo', '$correo', '$contrasena')";

    //Correo no se repita
    $verificar_correo = mysqli_query($conexion, "SELECT * FROM usuarios WHERE correo = ' $correo' ");

    if(mysqli_num_rows($verificar_correo) > 0){
        echo '
            <script>
                alert("Correo ya existente");
                window.location = "../iniciodessesion.php";
            </script>
        ';
        exit;
    }

    //usuario no se repita
   
    $ejecutar = mysqli_query($conexion, $query);

    if( $ejecutar){
        echo '
            <script>
                alert("Usuario registrado");
                window.location = "../iniciodessesion.php";
            </script>
        ';
    }else{
        echo '
        <script>
            alert("Usuario no almacenado");
            window.location = "../iniciodessesion.php";
        </script>
    '; 
    }

    mysqli_close($conexion);

?>