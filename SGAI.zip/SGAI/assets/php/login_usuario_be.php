<?php 

    include 'conexion_be.php';

    $nombre_completo =  $_POST['nombre_completo'];
    $contrasena = $_POST['contrasena'];

    $validar_login = mysqli_query($conexion," SELECT * FROM usuarios WHERE 
    nombre_completo = '$nombre_completo' and contrasena = '$contrasena'");

    if(mysqli_num_rows($validar_login) > 0){
        header("location: http://localhost/php/inicio.php");
        exit();
    }else{
        echo'
            <script>
                alert("El usuario no existe");
                window.location = "../inicio.php";
            </script>
        ';
        exit();
    }
   /* session_destroy();*/

?>