<?php 

    $conexion = mysqli_connect("localhost","root","","ini");

       
    if($conexion){
        echo 'Bro! Estoy conectado a la BD';
    }else{
        echo 'No se ha podido conectar';
    }
    

?>