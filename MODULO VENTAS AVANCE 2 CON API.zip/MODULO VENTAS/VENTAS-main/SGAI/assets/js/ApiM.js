function getWeatherData() {
    const apiKey = '323d2e6a08ed0372689de60775b6b258';  // Reemplaza con tu API Key
    const city = document.getElementById('city').value;
    const weatherUrl = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric&lang=es`;

    fetch(weatherUrl)
        .then(response => response.json())
        .then(data => {
            if (data.cod === 200) {
                const weatherOutput = `
                    <div class="alert alert-success">
                        <h6><strong>Ciudad:</strong> ${data.name}</h6>
                        <p><strong>Temperatura:</strong> ${data.main.temp}°C</p>
                        <p><strong>Clima:</strong> ${data.weather[0].description}</p>
                        <p><strong>Humedad:</strong> ${data.main.humidity}%</p>
                        <p><strong>Viento:</strong> ${data.wind.speed} m/s</p>
                    </div>
                `;
                document.getElementById('weather-output').innerHTML = weatherOutput;
            } else {
                document.getElementById('weather-output').innerHTML = `<div class="alert alert-danger">No se encontraron resultados para la ciudad ingresada.</div>`;
            }
        })
        .catch(error => {
            document.getElementById('weather-output').innerHTML = `<div class="alert alert-danger">Ocurrió un error al obtener los datos del clima.</div>`;
        });
}